# Delivery Plan

## Sprint 0 — Repair acceptance

- validate D93 artifact parsability
- approve C4/system model
- approve feature matrix
- approve repo placement

## Sprint 1 — Contract spine

- expand OpenAPI schemas
- expand AsyncAPI channels/messages
- expand projection JSON schemas
- generate mock server
- generate DTO smoke tests

## Sprint 2 — Policy spine

- simulate RBAC/ABAC
- enforce redaction fixtures
- admin allowlist tests
- notification negative tests
- LLM boundary evals

## Sprint 3 — Scaffold implementation

- Shared Core interfaces
- iOS shell
- Android shell
- Web Ops shell
- CI gates

## Sprint 4 — Controlled feature implementation

Only after passing gates:
- check-in
- state projection
- recommendation projection
- protocol execution
- reflection/learning
- notification re-entry
- Web Ops support
