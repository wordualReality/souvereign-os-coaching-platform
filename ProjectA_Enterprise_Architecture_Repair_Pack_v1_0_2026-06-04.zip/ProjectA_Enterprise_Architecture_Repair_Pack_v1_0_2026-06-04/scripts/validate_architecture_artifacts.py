from pathlib import Path
import json
import sys
import yaml
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]

yaml_files = list(ROOT.rglob("*.yaml")) + list(ROOT.rglob("*.yml"))
json_files = list(ROOT.rglob("*.json"))

errors = []

for f in yaml_files:
    try:
        yaml.safe_load(f.read_text(encoding="utf-8"))
    except Exception as e:
        errors.append(f"YAML parse failed: {f}: {e}")

for f in json_files:
    try:
        data = json.loads(f.read_text(encoding="utf-8"))
        if isinstance(data, dict) and "$schema" in data:
            Draft202012Validator.check_schema(data)
    except Exception as e:
        errors.append(f"JSON/schema parse failed: {f}: {e}")

required = [
    "07_API_CONTRACTS_OPENAPI/openapi-mobile-v1.yaml",
    "07_API_CONTRACTS_OPENAPI/openapi-ops-v1.yaml",
    "08_EVENT_CONTRACTS_ASYNCAPI/asyncapi-events-v1.yaml",
    "09_READ_MODELS_JSON_SCHEMA/projection-envelope-v1.schema.json",
    "10_SECURITY_POLICY_RBAC_ABAC/webops-rbac-policy-v1.yaml",
    "10_SECURITY_POLICY_RBAC_ABAC/redaction-policy-v1.yaml",
    "10_SECURITY_POLICY_RBAC_ABAC/admin-command-allowlist-v1.yaml",
]
for rel in required:
    if not (ROOT / rel).exists():
        errors.append(f"Required artifact missing: {rel}")

if errors:
    print("\n".join(errors))
    sys.exit(1)

print(f"Validated {len(yaml_files)} YAML files and {len(json_files)} JSON files.")
