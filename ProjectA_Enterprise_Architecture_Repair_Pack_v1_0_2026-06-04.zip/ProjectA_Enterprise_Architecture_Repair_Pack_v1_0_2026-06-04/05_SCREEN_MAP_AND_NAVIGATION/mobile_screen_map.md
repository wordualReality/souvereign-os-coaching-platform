# Mobile Screen Map

## Public / unauthenticated

- Launch
- Login / magic link / SSO placeholder
- Tenant selection / context pending
- Consent onboarding
- Notification permission rationale

## Main authenticated

- Home
  - Current state card
  - Recommendation card
  - Active protocol card
  - Reflection prompt card
  - Learning summary card
  - Stale/degraded banner
- Check-in
  - quick input
  - guided input
  - draft recovery
  - submit pending/offline
- Protocol Playback
  - step view
  - timer/haptic placeholder
  - complete step
  - abort
  - pending sync
- Reflection
  - prompt
  - draft
  - submit
  - local draft warning
- Learning
  - summary cards
  - pattern explanations
- Notifications
  - permission state
  - re-entry state
- Settings
  - account/session
  - consent/permissions
  - local data purge
  - device registration
