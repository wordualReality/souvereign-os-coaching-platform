# Web Ops Screen Map

## Operator

- Login / session
- Role/scope selector
- Elevation request
- Break-glass request

## Operations

- Tenant runtime health dashboard
- Worker/outbox/dead-letter dashboard
- Projection health dashboard
- Notification provider diagnostics
- Deployment/version view

## Support

- User search within scope
- User support context
- Redacted timeline
- Decision trace inspection
- Protocol execution inspection
- Reflection metadata inspection
- Sensitive reveal modal

## Audit / Replay

- Audit event search
- Audit detail view
- Audit export request/status
- Replay request
- Replay status/result view

## Incident / Admin

- Incident board
- Incident detail/timeline
- Runbook refs
- Admin command registry
- Command approval/elevation state
- Command result and rollback/mitigation view
