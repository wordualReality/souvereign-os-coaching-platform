# Feature Handoff Matrix

| Capability | Mobile | Web Ops | Shared Core | Contract Artifact | Production Status |
|---|---|---|---|---|---|
| Check-in | capture/draft/submit | inspect status | validate/accept | OpenAPI + CheckIn schema | blocked until contract tests |
| State | display projection | inspect trace | compute | CurrentStateProjection schema | blocked until projection tests |
| Routing | display recommendation | inspect decision trace | compute route | RecommendationProjection + event schemas | blocked until Core tests |
| Protocol execution | playback/pending sync | inspect execution | execution truth | ProtocolExecution schemas | blocked until outbox/reconcile tests |
| Reflection | draft/submit | metadata/redacted view | accept/reject | Reflection schema + redaction policy | blocked until D85 schemas |
| Learning | summary cards | pipeline status | pattern/input truth | Learning schemas | blocked until tests |
| Notifications | permission/open/reentry | diagnostics | policy/reentry | Notification schemas + payload policy | blocked until negative tests |
| Web Ops support | none | support context/timeline | controlled projections | Ops OpenAPI + RBAC policies | blocked until policy tests |
| Audit | implicit user actions | search/export | immutable evidence | Audit schema/policy | blocked until audit lifecycle tests |
| Replay | none | request/view | reconstruct non-mutating | AsyncAPI + replay schema | blocked until replay tests |
| Admin commands | none | allowlisted shell | typed execution | Admin policy YAML | blocked until approval tests |
| LLM assist | disabled draft/explain | disabled summarize/draft | no authority | LLM policy/evals | blocked until evals |
