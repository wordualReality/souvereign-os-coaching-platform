# User Journey Map

## Core end-user loop

1. Open app
2. Session/tenant context resolved
3. Complete check-in
4. Core computes state
5. Core produces recommendation
6. User starts protocol
7. User progresses/aborts/completes protocol
8. User reflects
9. Core learns from accepted inputs
10. User sees learning summary over time

## Support loop

1. Operator logs into Web Ops
2. Selects tenant/support case
3. Opens redacted user timeline
4. Inspects decision trace/protocol execution
5. If needed requests elevation for sensitive reveal
6. Adds support note
7. Links incident/replay/admin command only through allowlisted path

## Ops loop

1. Platform operator opens tenant health dashboard
2. Checks worker/projection/outbox lag
3. Requeues job or rebuilds projection only if allowlisted
4. Audit before/after record created
5. Incident/evidence linked
