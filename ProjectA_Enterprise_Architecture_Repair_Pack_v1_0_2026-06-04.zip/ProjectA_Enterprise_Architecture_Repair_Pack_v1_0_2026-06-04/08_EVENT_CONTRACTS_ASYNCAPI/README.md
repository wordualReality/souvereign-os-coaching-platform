# AsyncAPI Event Contracts

This folder contains the v0.1 AsyncAPI event skeleton.

Rules:
- clients never emit authoritative domain events
- server emits events after commit
- outbox/equivalent reliability pattern required
- consumers must be idempotent
