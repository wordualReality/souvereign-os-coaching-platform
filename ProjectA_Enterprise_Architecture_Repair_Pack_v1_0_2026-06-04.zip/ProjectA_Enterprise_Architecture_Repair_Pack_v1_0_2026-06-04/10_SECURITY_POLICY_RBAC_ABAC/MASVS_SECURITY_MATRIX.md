# MASVS Security Matrix — Project A

| MASVS Area | Project A Control | Required Test |
|---|---|---|
| Storage | tokens in Keychain/Keystore, sensitive drafts encrypted/protected | local storage inspection |
| Crypto | platform key storage, no hardcoded keys | static analysis + runtime check |
| Auth | server-side authz, no local-only auth decisions | auth bypass tests |
| Network | TLS, no sensitive logs, no self-signed production server | network security config tests |
| Platform | no sensitive IPC/deep-link payloads | deep-link negative tests |
| Code | lint/static analysis, no secrets | CI static checks |
| Resilience | jailbreak/root/tamper risk signal only | non-blocking risk tests |
| Privacy | no sensitive notification payload, no raw reflection telemetry | notification/log telemetry tests |
