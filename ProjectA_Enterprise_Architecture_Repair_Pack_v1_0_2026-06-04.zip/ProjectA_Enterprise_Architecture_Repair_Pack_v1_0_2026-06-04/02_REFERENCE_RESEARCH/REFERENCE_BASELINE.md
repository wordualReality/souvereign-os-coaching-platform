# Reference Baseline

This repair pack is measured against current software architecture and mobile implementation standards.

## Architecture modeling

- C4: context, container, component, code plus dynamic/deployment supporting diagrams.
- arc42-compatible coverage: goals, constraints, context, building blocks, runtime view, deployment view, crosscutting concepts, risks, quality, decisions.

## API contracts

- OpenAPI for HTTP API surface contracts.
- AsyncAPI for event/message-driven API contracts.
- JSON Schema for projection/read-model contracts.

## Mobile security

- OWASP MASVS/MASWE categories: storage, cryptography, authentication, network, platform interaction, code, resilience, privacy.
- Mandatory negative tests: sensitive data in logs, local storage, notifications, backups, screenshots, IPC/deep links.

## Open-source reference repos reviewed as maturity signal

- Mattermost Mobile: native folders, tests, detox, fastlane, docs, security, CI/build metadata.
- Rocket.Chat React Native: mobile app repo, test and automation structures.
- Bitwarden Android: security-sensitive Android architecture with app/core/data/network/ui/testharness style modularity.
- Nextcloud iOS: app plus extensions, tests, SwiftLint/security structure.

## Consequence for Project A

Text dossiers are not sufficient. The handoff needs parseable contract files, diagrams, policies, tests, and build sequencing.
