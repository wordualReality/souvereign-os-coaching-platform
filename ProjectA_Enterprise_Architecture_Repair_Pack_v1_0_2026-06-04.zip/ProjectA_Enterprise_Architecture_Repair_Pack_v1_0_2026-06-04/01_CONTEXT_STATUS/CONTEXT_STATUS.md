# Context Status

## Project

Project A — Sovereign OS Operator Apps and Shared Core.

## Current architectural state

- semantic architecture D72-D92 exists
- earlier handoff bundle v0.2 is insufficient for enterprise handoff
- D93 repairs the pack by adding executable architecture artifacts

## Current goal

Move from architecture prose to implementable system contract.

## Fixed decisions

- native iOS and native Android are primary mobile surfaces
- Web Ops is privileged operations/support/admin/audit surface
- Shared Core owns runtime truth
- Project B owns coach, tenant, journey, content publication, commerce and delivery truth
- Canonical/shared DB owns canonical references
- mobile offline is resilience only
- LLM assist is non-authoritative and disabled by default
- notifications are re-entry hints, not truth
- admin commands are allowlisted and audited

## New package status

D93 Repair Pack v1.0 provides:
- diagrams
- OpenAPI v0.1
- AsyncAPI v0.1
- projection schemas
- RBAC/ABAC policy YAML
- threat model
- CI gate skeleton
- Cursor prompts and task plan
