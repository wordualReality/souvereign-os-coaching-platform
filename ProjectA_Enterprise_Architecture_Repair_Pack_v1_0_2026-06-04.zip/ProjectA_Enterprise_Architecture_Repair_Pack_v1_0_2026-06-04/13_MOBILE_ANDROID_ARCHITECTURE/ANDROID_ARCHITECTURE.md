# Android Architecture

## Modules

- app
- core
- data
- network
- feature-checkin
- feature-protocol
- feature-reflection
- feature-learning
- feature-notifications
- offline-outbox
- secure-storage
- feature-flags

## Platform rules

- tokens: Android Keystore backed storage
- sensitive local drafts: encrypted Room or encrypted storage
- non-sensitive preferences: DataStore
- push: FCM
- background: WorkManager
- Health Connect: future seam, policy gated

## Forbidden

- no local state computation
- no local routing
- no protocol legality override
- no sensitive notification payload
