# iOS Architecture

## Modules

- AppShell
- AuthSession
- TenantContext
- MobileApiClient
- ProjectionStore
- CheckInFeature
- ProtocolPlaybackFeature
- ReflectionFeature
- LearningFeature
- NotificationFeature
- OfflineOutbox
- SecureStorage
- FeatureFlags

## Platform rules

- tokens: Keychain
- sensitive local drafts: protected encrypted persistence
- non-sensitive preferences: UserDefaults
- push: APNs
- background: best-effort BackgroundTasks
- HealthKit/EventKit: future seam, policy gated

## Forbidden

- no local state computation
- no local routing
- no protocol legality override
- no sensitive notification payload
