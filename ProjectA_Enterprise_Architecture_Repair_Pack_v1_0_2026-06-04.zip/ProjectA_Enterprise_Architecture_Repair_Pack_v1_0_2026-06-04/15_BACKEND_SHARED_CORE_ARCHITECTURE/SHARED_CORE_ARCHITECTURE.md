# Shared Core Architecture

## Components

- API Facade Adapters
- Command Application Layer
- Policy Enforcement
- Consent/Entitlement Service
- Check-in Service
- State Computation Service
- Routing/Recommendation Service
- Protocol Execution Service
- Reflection Service
- Learning Service
- Notification/Re-entry Service
- Projection Producers
- Event/Outbox Publisher
- Audit Service
- Replay Service
- Admin Command Executor

## Authority

Shared Core is the only runtime authority for state, routing, protocol execution truth, reflection acceptance, learning patterns, consent and entitlement enforcement.

## Package boundary rule

No surface package may import domain mutation internals directly.
