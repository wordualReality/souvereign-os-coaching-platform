# Observability Model

## Required correlation

`correlation_id` must connect:

- API request
- command
- domain event
- audit event
- log line
- trace span
- projection update
- Web Ops evidence link

## Signals

- API latency/error rate
- outbox lag
- dead-letter count
- projection freshness
- worker failures
- admin command state
- audit export lifecycle
- replay lifecycle
- notification delivery/receipt status
- LLM invocation status where enabled

## Dashboards

- Tenant runtime health
- Projection health
- Worker/outbox health
- Notification provider health
- Audit/export health
- Admin command execution
- Incident evidence
