# OpenAPI Contracts

These contracts are v0.1 executable skeletons.

Validation target:
- must parse as YAML
- must satisfy OpenAPI 3.1 structure at skeleton level
- must drive DTO generation only after schema completion

Files:
- openapi-mobile-v1.yaml
- openapi-ops-v1.yaml
- openapi-shared-components-v1.yaml
