# Test Strategy

## Gate families

1. Contract tests
2. Policy tests
3. Runtime authority tests
4. Mobile offline/security tests
5. Web Ops privileged access tests
6. Event/outbox tests
7. Notification negative tests
8. LLM boundary tests
9. Observability tests

## Immediate executable gate

Run:

```bash
python scripts/validate_architecture_artifacts.py
```

This validates that YAML/JSON artifacts parse and that JSON Schemas compile.
