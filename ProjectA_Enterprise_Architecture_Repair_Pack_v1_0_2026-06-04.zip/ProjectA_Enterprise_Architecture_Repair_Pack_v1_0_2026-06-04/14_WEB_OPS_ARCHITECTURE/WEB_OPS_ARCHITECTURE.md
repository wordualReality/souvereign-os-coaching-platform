# Web Ops Architecture

## Modules

- OperatorSession
- ScopeSelector
- PolicyMiddleware
- RedactionService
- TenantHealth
- SupportTimeline
- DecisionTraceInspection
- ProtocolExecutionInspection
- AuditSearchExport
- IncidentBoard
- ReplayConsole
- AdminCommandRegistry
- ObservabilityViews

## Rule

Web Ops renders only server-filtered and server-redacted data.

## Forbidden

- no direct DB edits
- no privileged data rendering without policy
- no admin execution outside allowlist
- no secret/token display
