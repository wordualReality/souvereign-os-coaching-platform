-- Project A runtime schema skeleton.
-- This is not final migration code. It is the DB handoff skeleton for ERD alignment.

create table tenants (
  id uuid primary key,
  display_name text not null,
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create table users (
  id uuid primary key,
  external_subject text unique,
  created_at timestamptz not null default now()
);

create table memberships (
  tenant_id uuid references tenants(id),
  user_id uuid references users(id),
  role text not null,
  status text not null,
  primary key (tenant_id, user_id)
);

create table checkins (
  id uuid primary key,
  tenant_id uuid references tenants(id),
  user_id uuid references users(id),
  idempotency_key text not null,
  payload jsonb not null,
  accepted_at timestamptz,
  created_at timestamptz not null default now(),
  unique (tenant_id, user_id, idempotency_key)
);

create table state_snapshots (
  id uuid primary key,
  tenant_id uuid references tenants(id),
  user_id uuid references users(id),
  checkin_id uuid references checkins(id),
  state_label text not null,
  confidence numeric,
  computed_at timestamptz not null
);

create table recommendations (
  id uuid primary key,
  tenant_id uuid references tenants(id),
  user_id uuid references users(id),
  state_snapshot_id uuid references state_snapshots(id),
  recommendation_type text not null,
  protocol_ref text,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

create table protocol_executions (
  id uuid primary key,
  tenant_id uuid references tenants(id),
  user_id uuid references users(id),
  recommendation_id uuid references recommendations(id),
  protocol_ref text not null,
  protocol_version text not null,
  state text not null,
  started_at timestamptz,
  completed_at timestamptz
);

create table reflections (
  id uuid primary key,
  tenant_id uuid references tenants(id),
  user_id uuid references users(id),
  protocol_execution_id uuid references protocol_executions(id),
  content_ref text not null,
  visibility_level text not null,
  accepted_at timestamptz not null default now()
);

create table audit_events (
  id uuid primary key,
  tenant_id uuid,
  actor_type text not null,
  actor_id uuid,
  subject_type text,
  subject_id uuid,
  action_type text not null,
  purpose_code text,
  decision text not null,
  correlation_id uuid not null,
  payload jsonb not null,
  occurred_at timestamptz not null default now()
);

create table outbox_events (
  id uuid primary key,
  event_name text not null,
  event_version text not null,
  tenant_id uuid,
  aggregate_type text,
  aggregate_id uuid,
  payload jsonb not null,
  correlation_id uuid not null,
  causation_id text,
  published_at timestamptz,
  created_at timestamptz not null default now()
);
