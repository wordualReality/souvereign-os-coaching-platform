# Read-model JSON Schemas

These are v0.1 executable JSON Schema skeletons for projections.

Contract invariant:
- projections are server-generated read models
- clients do not treat projections as write authority
- freshness and authority metadata are required through ProjectionEnvelope
