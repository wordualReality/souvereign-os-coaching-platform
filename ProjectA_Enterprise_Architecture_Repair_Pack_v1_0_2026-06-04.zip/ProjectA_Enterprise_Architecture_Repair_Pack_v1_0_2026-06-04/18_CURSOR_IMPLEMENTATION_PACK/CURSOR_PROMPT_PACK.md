# Cursor Prompt Pack — D93 Repair Pack

## Prompt 1 — Create repo scaffold

Use this D93 Repair Pack as source. Create a repository scaffold only. Implement directory structure, README guardrails, validation script, and CI workflow. Do not implement production domain behavior.

## Prompt 2 — Contract validation

Wire OpenAPI/AsyncAPI/JSON Schema validation commands. Keep DTO generation disabled until schemas validate.

## Prompt 3 — Core interfaces

Create Shared Core interfaces only: commands, projections, outbox, audit hooks, policy enforcement, notification re-entry, reflection/learning, replay, admin command execution. No final algorithms.

## Prompt 4 — iOS shell

Create native iOS shell with mock projections. No local state/routing/protocol authority.

## Prompt 5 — Android shell

Create native Android shell with mock projections, WorkManager outbox abstraction, secure storage abstraction. No local authority.

## Prompt 6 — Web Ops shell

Create Web Ops shell with redacted mock data, policy state labels, admin registry disabled. No real privileged data.

## Prompt 7 — Verification

Run validation script and produce report against D93 manifest. Flag missing artifacts and any authority drift.
