# Threat Model

## Primary assets

- reflection raw content
- check-in payloads
- state snapshots
- recommendation traces
- protocol execution history
- learning patterns
- audit evidence
- admin command records
- notification tokens
- mobile local drafts/outbox
- tenant/user identity links

## Trust boundaries

1. Mobile device <-> Mobile API
2. Web browser <-> Ops API
3. API <-> Shared Core
4. Shared Core <-> Runtime DB / Audit DB / Projection Store
5. Shared Core <-> Project B refs
6. Shared Core <-> Canonical DB
7. Notification Service <-> APNs/FCM
8. LLM boundary <-> retrieved context

## Threats and controls

| Threat | Control |
|---|---|
| mobile cached recommendation shown as current | freshness metadata + stale UI |
| raw reflection leaked to support | server-side redaction + elevation + audit |
| token in logs | logging filter + static checks |
| sensitive push payload | notification policy + negative fixture |
| admin command abuse | allowlist + approval + audit |
| LLM authority drift | disabled default + output validators |
| prompt injection | retrieved content treated as data |
| replay mutates production | replay is non-mutating by contract |
| cross-tenant access | ABAC tenant scope + denied audit |
