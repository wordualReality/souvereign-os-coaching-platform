# ProjectA Enterprise Architecture Repair Pack v1.0 Manifest

## Purpose

Repair the previous prose-heavy architecture bundle by adding executable architecture artifacts.

## Contents

- C4 diagrams
- screen maps
- domain ERD
- SQL skeleton
- OpenAPI contracts
- AsyncAPI contract
- JSON Schemas
- RBAC/ABAC/redaction/admin policies
- MASVS matrix
- threat model
- platform architecture docs
- observability model
- CI validation workflow
- validation script
- Cursor prompt pack
- delivery plan

## Validation

Run:

```bash
python scripts/validate_architecture_artifacts.py
```

## Status

Enterprise repair pack: usable for architecture-controlled scaffold kickoff.

Not production-ready:
- contracts are v0.1 skeletons
- schemas require expansion
- policies require implementation
- tests require executable fixture completion
